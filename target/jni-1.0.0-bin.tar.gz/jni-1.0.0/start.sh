#! /bin/sh

java -cp lib/:classes/ learn.jni.Sample01